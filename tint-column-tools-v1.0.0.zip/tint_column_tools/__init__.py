bl_info = {
    "name": "Tint Column Tools",
    "version": (1, 0, 0),
    "blender": (5, 3, 0),
    "location": "3D View > Sidebar > Tint",
    "description": "Preview and apply Sollumz palette columns and detach hidden duplicate models",
    "category": "Material",
}

import sys
from collections import Counter

import bpy


_preview = {}
_enum_items = []


def _targets(obj):
    if obj is None or obj.type != "MESH":
        return
    for mod in obj.modifiers:
        if mod.type != "NODES" or not mod.node_group or not mod.node_group.name.startswith("TintGeometry"):
            continue
        sockets = mod.node_group.interface.items_tree
        names = ("Color Attribute", "Tint Color", "Palette Texture", "Palette (Preview)")
        if not all(sockets.get(name) for name in names):
            continue
        source = getattr(mod.properties.inputs, sockets[names[0]].identifier)
        field = "attribute_name" if hasattr(source, "attribute_name") else "value"
        output = getattr(mod.properties.outputs, sockets[names[1]].identifier).attribute_name
        image = getattr(mod.properties.inputs, sockets[names[2]].identifier).value
        row = int(getattr(mod.properties.inputs, sockets[names[3]].identifier).value)
        yield mod, source, field, output, image, row


def _items(self, context):
    items = [("ALL", "All Tint Modifiers", "Use every matching tint modifier", 0)]
    for index, (mod, _, _, output, _, _) in enumerate(_targets(context.object), 1):
        items.append((f"TINT_{index}", f"{mod.name} | {output}", "", index))
    _enum_items[:] = items
    return _enum_items


def _selected_groups(context):
    obj = context.object
    if obj is None or obj.type != "MESH" or obj.mode != "OBJECT":
        return []
    target = context.window_manager.tint_column_target
    selected = [face for face in obj.data.polygons if face.select]
    groups = []
    for index, (_, socket, field, output, image, row) in enumerate(_targets(obj), 1):
        if target not in ("ALL", f"TINT_{index}"):
            continue
        attr = obj.data.color_attributes.get(getattr(socket, field))
        if attr is None or attr.domain != "CORNER" or attr.data_type != "BYTE_COLOR":
            continue
        slots = {
            i for i, mat in enumerate(obj.data.materials)
            if mat and mat.node_tree and any(
                n.type == "ATTRIBUTE" and n.attribute_name == output for n in mat.node_tree.nodes
            )
        }
        faces = [face for face in selected if face.material_index in slots]
        if faces:
            groups.append((socket, field, attr.name, faces, image, row))
    return groups


def _refresh(obj):
    obj.data.update()
    obj.update_tag(refresh={"DATA"})


def _write_column(attr, corners, column):
    for i in corners:
        red, green, _, alpha = attr.data[i].color_srgb
        attr.data[i].color_srgb = (red, green, column / 255, alpha)


def _finish(apply=False):
    if not _preview:
        return
    obj = _preview["object"]
    attributes = obj.data.color_attributes
    for socket, field, source, temporary, corners in _preview["groups"]:
        original = attributes.get(source)
        if apply and original:
            _write_column(original, corners, _preview["column"])
        setattr(socket, field, source)
        attr = attributes.get(temporary)
        if attr:
            attributes.remove(attr)
    _preview.clear()
    _refresh(obj)


def _update_target(self, context):
    if not _preview or _preview["object"].mode == "OBJECT":
        _finish()


def _get_column(self):
    if _preview:
        return _preview["column"]
    groups = _selected_groups(bpy.context)
    if groups:
        _, _, source, faces, _, _ = groups[0]
        attr = bpy.context.object.data.color_attributes[source]
        return round(attr.data[faces[0].loop_start].color_srgb[2] * 255)
    return 0


def _set_column(self, column):
    context = bpy.context
    obj = context.object
    if obj is None or obj.mode != "OBJECT" or (_preview and _preview["object"] != obj):
        return
    if not _preview:
        groups = _selected_groups(context)
        if not groups:
            return
        attributes = obj.data.color_attributes
        _preview.update(object=obj, groups=[], column=column, face_count=0)
        faces = set()
        try:
            for socket, field, source, selection, image, row in groups:
                original = attributes[source]
                colors = [0.0] * (4 * len(original.data))
                original.data.foreach_get("color_srgb", colors)
                temporary = attributes.new(name="TintColor (Live Preview)", type="BYTE_COLOR", domain="CORNER")
                corners = [i for face in selection for i in face.loop_indices]
                _preview["groups"].append((socket, field, source, temporary.name, corners))
                temporary.data.foreach_set("color_srgb", colors)
                setattr(socket, field, temporary.name)
                faces.update(face.index for face in selection)
            _preview["face_count"] = len(faces)
            _preview["palette"] = groups[0][4:6]
        except Exception:
            _finish()
            raise
    _preview["column"] = column
    for _, _, _, temporary, corners in _preview["groups"]:
        _write_column(obj.data.color_attributes[temporary], corners, column)
    _refresh(obj)


def _get_swatch(self):
    if not _preview:
        return (0, 0, 0)
    image, row = _preview["palette"]
    if image and all(image.size):
        width, height = image.size
        row = height - 1 - min(max(row, 0), height - 1)
        offset = 4 * (row * width + min(_preview["column"], width - 1))
        return tuple(image.pixels[offset:offset + 3])
    return (0, 0, 0)


def _drawable(obj):
    if obj is None:
        return None
    if getattr(obj, "sollum_type", None) == "sollumz_drawable":
        return obj
    if obj.parent and getattr(obj.parent, "sollum_type", None) == "sollumz_drawable":
        return obj.parent
    return None


def _signatures(obj, mesh):
    positions = [
        tuple(round(value, 6) for value in obj.matrix_world @ vertex.co)
        for vertex in mesh.vertices
    ]
    signatures = Counter()
    for face in mesh.polygons:
        points = tuple(positions[i] for i in face.vertices)
        start = points.index(min(points))
        material = mesh.materials[face.material_index] if face.material_index < len(mesh.materials) else None
        signatures[material, points[start:] + points[:start]] += 1
    return signatures


def _duplicates(drawable, view_layer):
    exporter = next((module for name, module in sys.modules.items() if name.endswith("sollumz.ydr.ydrexport")), None)
    if exporter is None:
        return []
    visible, hidden = [], []
    for obj in exporter.get_model_objs(drawable):
        if obj.type != "MESH" or obj.vertex_groups or obj.children or obj.constraints or obj.animation_data:
            continue
        if any(mod.type != "NODES" or not mod.node_group or not mod.node_group.name.startswith("TintGeometry") for mod in obj.modifiers):
            continue
        lods = {}
        for level in exporter.LODLevel:
            mesh = obj.sz_lods.get_lod(level).mesh
            if mesh and mesh.polygons:
                lods[level] = _signatures(obj, mesh)
        if lods:
            (visible if obj.visible_get(view_layer=view_layer) else hidden).append((obj, lods))
    return [
        obj for obj, lods in hidden
        if any(all(level in cover and faces <= cover[level] for level, faces in lods.items()) for _, cover in visible)
    ]


class TINTTOOLS_OT_apply(bpy.types.Operator):
    bl_idname = "tinttools.apply"
    bl_label = "Apply Tint"
    bl_options = {"UNDO"}

    def execute(self, context):
        if not _preview or context.object != _preview["object"] or context.object.mode != "OBJECT":
            return {"CANCELLED"}
        _finish(apply=True)
        return {"FINISHED"}


class TINTTOOLS_OT_cancel(bpy.types.Operator):
    bl_idname = "tinttools.cancel"
    bl_label = "Cancel Preview"

    def execute(self, context):
        if not _preview or _preview["object"].mode != "OBJECT":
            return {"CANCELLED"}
        _finish()
        return {"FINISHED"}


class TINTTOOLS_OT_detach(bpy.types.Operator):
    bl_idname = "tinttools.detach"
    bl_label = "Detach Hidden Duplicates"
    bl_options = {"UNDO"}

    def execute(self, context):
        drawable = _drawable(context.object)
        if drawable is None or context.mode != "OBJECT":
            return {"CANCELLED"}
        duplicates = _duplicates(drawable, context.view_layer)
        if not duplicates:
            self.report({"INFO"}, "No fully overlapping hidden models found")
            return {"CANCELLED"}
        for obj in duplicates:
            world = obj.matrix_world.copy()
            obj.parent = None
            obj.matrix_world = world
        self.report({"INFO"}, "Detached: " + ", ".join(obj.name for obj in duplicates))
        return {"FINISHED"}


class TINTTOOLS_PT_panel(bpy.types.Panel):
    bl_label = "Tint Column"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tint"

    def draw(self, context):
        layout = self.layout
        wm = context.window_manager
        obj = context.object
        if _preview and obj != _preview["object"]:
            layout.label(text=f"Preview active on {_preview['object'].name}")
            layout.operator("tinttools.cancel")
        elif obj and obj.type == "MESH" and obj.mode == "OBJECT":
            layout.prop(wm, "tint_column_target")
            if _preview or _selected_groups(context):
                layout.prop(wm, "tint_column_value", slider=True)
                if _preview:
                    layout.label(text=f"Previewing {_preview['face_count']} faces")
                    swatch = layout.row()
                    swatch.enabled = False
                    swatch.prop(wm, "tint_column_swatch")
                    row = layout.row(align=True)
                    row.operator("tinttools.apply")
                    row.operator("tinttools.cancel")
            else:
                layout.label(text="Select faces that use the chosen tint")
        else:
            layout.label(text="Select faces, then return to Object Mode")
        if context.mode == "OBJECT" and _drawable(obj):
            layout.operator("tinttools.detach")


_CLASSES = (TINTTOOLS_OT_apply, TINTTOOLS_OT_cancel, TINTTOOLS_OT_detach, TINTTOOLS_PT_panel)


def register():
    wm = bpy.types.WindowManager
    wm.tint_column_target = bpy.props.EnumProperty(name="Tint Modifier", items=_items, update=_update_target)
    wm.tint_column_value = bpy.props.IntProperty(name="Palette Column", min=0, max=255, get=_get_column, set=_set_column)
    wm.tint_column_swatch = bpy.props.FloatVectorProperty(name="Palette Color", subtype="COLOR_GAMMA", size=3, get=_get_swatch)
    for cls in _CLASSES:
        bpy.utils.register_class(cls)


def unregister():
    _finish()
    for cls in reversed(_CLASSES):
        bpy.utils.unregister_class(cls)
    for name in ("tint_column_target", "tint_column_value", "tint_column_swatch"):
        delattr(bpy.types.WindowManager, name)
